function dhiya()
{
    document.getElementById("myImg").src = "/images/pic1.jpg";
}
function liya()
{
    document.getElementById("myImg").src = "/images/pic2.jpg";
}
function jeffin()
{
    document.getElementById("myImg").src = "/images/pic3.jpg";
}