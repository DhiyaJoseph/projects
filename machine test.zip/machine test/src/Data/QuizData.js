export const QuizData = [
    {
        question: "What is the capital city of France?",
        options: ["Berlin", "London", "Paris", "Madrid"],
        answer: 3
    },
    {
        question: "Which planet is known as the 'Red Planet'?",
        options: ["Mars", "Venus", "Jupiter", "Saturn"],
        answer: 1
    },
    {
        question: "Who wrote 'Romeo and Juliet'?",
        options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
        answer: 2
    },
    {
        question: "In what year did the United States declare its independence?",
        options: ["1776", "1789", "1800", "1812"],
        answer: 1
    },
];
